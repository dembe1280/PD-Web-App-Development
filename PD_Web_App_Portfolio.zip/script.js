// Loader
window.addEventListener("load", () => {
  const loader = document.getElementById("loader");
  loader.style.opacity = "0";
  loader.style.pointerEvents = "none";
  setTimeout(() => loader.style.display = "none", 500);
});

// Mobile Menu
const menuBtn = document.getElementById("menuBtn");
const nav = document.getElementById("nav");

menuBtn.addEventListener("click", () => {
  nav.classList.toggle("active");
});

document.querySelectorAll("#nav a").forEach(link => {
  link.addEventListener("click", () => {
    nav.classList.remove("active");
  });
});

// Dark Mode
const themeBtn = document.getElementById("themeBtn");
const body = document.body;

if(localStorage.getItem("theme") === "dark"){
  body.classList.add("dark");
  themeBtn.innerHTML = '<i class="fas fa-sun"></i>';
}

themeBtn.addEventListener("click", () => {
  body.classList.toggle("dark");

  if(body.classList.contains("dark")){
    localStorage.setItem("theme","dark");
    themeBtn.innerHTML = '<i class="fas fa-sun"></i>';
  }else{
    localStorage.setItem("theme","light");
    themeBtn.innerHTML = '<i class="fas fa-moon"></i>';
  }
});

// Back To Top
const topBtn = document.getElementById("topBtn");

window.addEventListener("scroll", () => {
  topBtn.style.display = window.scrollY > 300 ? "block" : "none";
  reveal();
});

topBtn.addEventListener("click", () => {
  window.scrollTo({
    top:0,
    behavior:"smooth"
  });
});

// Scroll Reveal
const reveals = document.querySelectorAll(
  ".card, .project, .about-card, .hero-content, .hero-box, .section-title, .info-box"
);

reveals.forEach(el => el.classList.add("reveal"));

function reveal(){
  reveals.forEach(el => {
    const top = el.getBoundingClientRect().top;
    if(top < window.innerHeight - 120){
      el.classList.add("active");
    }
  });
}

reveal();

// Counter Animation
const counters = document.querySelectorAll(".stats h2");

function runCounters(){
  counters.forEach(counter => {
    const target = +counter.dataset.target;
    const current = +counter.innerText;

    if(current < target){
      counter.innerText = current + 1;
      setTimeout(runCounters, 40);
    }
  });
}

let counted = false;

window.addEventListener("scroll", () => {
  const stats = document.querySelector(".stats");

  if(!counted && window.scrollY + window.innerHeight > stats.offsetTop + 100){
    counted = true;
    runCounters();
  }
});

// Contact Form
document.getElementById("contactForm").addEventListener("submit", function(e){
  e.preventDefault();
  alert("Thank you! Your message has been received.");
  this.reset();
});
